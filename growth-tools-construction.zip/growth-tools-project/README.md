# Growth Tools — Construction App

## Sobre o Projeto
SaaS de FP&A e BI especializado para incorporadoras imobiliárias.
Cliente piloto: RMV Empreendimentos / BMV Construções — SIGNATURE SUARÃO (195 unidades MCMV/PEC).
Empresa: Tools for Growth (TFG) — Co-fundadores: Thiago, Dr. Kleber Ferreira, Fernando Jorge.

## Stack atual (protótipo)
- HTML5 + CSS puro + JavaScript ES6+ (vanilla)
- Chart.js 4.4.1 (CDN)
- XLSX.js 0.18.5 (CDN)
- Font Awesome 6.5 (CDN)
- Arquivo único: growth-tools-construction.html (~200KB)
- Zero dependências instaladas, zero backend

## Stack de produção planejada
- Frontend: Next.js 14 + TypeScript + Tailwind CSS
- Backend: Supabase (PostgreSQL + Auth + Storage + RLS)
- Deploy: Vercel Pro
- Open Finance: Pluggy ou Belvo (agregador bancário)

## Como usar o protótipo
Abrir o arquivo `growth-tools-construction.html` diretamente no browser.
Não requer servidor ou instalação.

## Estrutura de telas (19 telas)

### Módulo Receitas
- Unidades / Dados de Venda
- Simulador (SAC/PRICE/SBPE)
- Reembolso
- Permuta
- Parâmetros / INCC

### Módulo Despesas
- Lançamentos de Despesas
- Fornecedores & Stakeholders
- Plano de Contas (CEF + DRE)

### Reports & Dashboards
- Dashboard (multi-versão: até 3 simultâneas)
- Projeção de Receitas
- Consolidado
- Caixa (janela 7 dias + previstas)
- DRE (por competência)
- Fluxo de Caixa Mensal
- Medição de Obra (imprimível para CEF)
- Rolling Forecast
- Resumo Executivo

### Config
- Usuários
- Acesso Contabilidade

## Arquitetura de versões
- Budget: plano fixo original
- Previsto/Forecast: revisão mensal
- Atual: realizado (extrato bancário)
- Customizadas: até 3 por projeto (total 6)
- Cada versão tem dados completamente isolados (units, despesas, reembolsos, caixa)

## Plano de Contas
10 grupos CEF (Orçamento Sintético Habitação) + 9 grupos complementares
Dupla classificação: Grupo CEF + Categoria DRE
Categorias DRE: Receita, Custo Variável, Custo Fixo, Despesa Variável, Despesa Fixa, Retiradas, Investimento

## Referências
- Planilha RMV v8: https://docs.google.com/spreadsheets/d/1v4ByD8hIJH3SUboKXsARq0lapfIDxl2xQjU2CvK93uA
- Formulário CEF FRE: Cronograma_CEF_Jul_26.xls
- Empreendimento: SIGNATURE SUARÃO — 195 ap. — Custo edificações: R$ 46.789.988,90

## Precificação piloto
R$ 1.200–1.500/mês (RMV — cliente fundador)
